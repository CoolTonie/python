#write a pyhthon program that adds 2 numbers and output the result
num1 = int(input('enter number 1: '))
num2 = int(input('enter number 2: '))
result= num1 + num2
print(num1,'+',num2,'=', result)
# second option to the first with a lil tweak, same idea basically
num1 = int(input('enter number 1: '))
num2 = int(input('enter number 2: '))
result= num1 + num2
print('sum of', num1,'and', 'sum of', num2,'=', result)